module.exports = {

    attributes: {

        hotel_id:{
            type: "string",
            required:true
        },
  
        question:{
            type: "string",
            required:true   
        },
  
        answer:{
            type: "text",
            required:true   
        },
  
    },
  
  };
  