module.exports = {

    attributes: {
  
        name:{
            type: "string",
            required:true   
        },

        icon:{
            type: "string",
            required:true   
        },

        is_custom:{
            type:"boolean",
            defaultsTo:false
        }
  
    },
  
  };
  
  