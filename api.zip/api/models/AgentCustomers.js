module.exports = {

    attributes: {
  
        userId:{
            type: "string",
            required:true   
        },
        name:{
            type: "string",
            required:false   
        },
        email:{
            type: "string",
            required:false   
        },
        contact:{
            type: "string",
            required:false   
        },
        address:{
            type: "string",
            required:false   
        },
        address:{
            type: "string",
            required:false   
        },


    }


}