module.exports = {

    attributes: {

        hotel_id: {
            type: 'string',
            required: true
        },
        invoice_path: {
            type: 'string',
            required: false
        },
        remark: {
            type: 'string',
            required: false
        }

    }
}