
module.exports = {

    attributes: {

        userId:{
            type:'string',
            required:false
        },

        email:{
            type:'string',
            required:false
        },

        mobile:{
            type:'string',
            required:false
        },

        startdate:{
            type:'string',
            required:false
        },

        enddate:{
            type:'string',
            required:false
        },

        persons:{
            type:'number',
            required:false
        },

        subject:{
            type:'string',
            required:false
        },

        content:{
            type:'text',
            required:true
        },




    }

}