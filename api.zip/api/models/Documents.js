
module.exports = {

    attributes: {
  
      userId:{
        type:'string',
        required:true
      },

      role:{
        type:'number',
        required:true
      },

      type:{
        type:'string',
        required:true
      },

      path:{
        type:'string',
        required:true
      }

    }

}