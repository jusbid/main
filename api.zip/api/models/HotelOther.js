module.exports = {

    attributes: {

        hotel_id: {
            type: 'string',
            required: true
        },

        type: {
            type: 'string',
            required: true
        },

        content: {
            type: 'text',
            required: true
        },


    }

}