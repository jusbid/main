module.exports = {

  attributes: {

      name:{
          type: "string",
          required:true   
      },

  },

};
